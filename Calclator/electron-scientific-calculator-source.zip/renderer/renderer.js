// ============ STATE ============
let currentInput = '0';
let previousInput = '';
let operator = null;
let angleMode = 'DEG'; // or 'RAD'
let isMuted = false;
let resultJustShown = false;

const currentOperandEl = document.getElementById('currentOperand');
const prevOperandEl = document.getElementById('prevOperand');
const angleModeEl = document.getElementById('angleMode');
const historyPanel = document.getElementById('historyPanel');
const historyList = document.getElementById('historyList');

// ============ MATH HELPERS ============
function toRadians(value) {
  return angleMode === 'DEG' ? (value * Math.PI) / 180 : value;
}

function cleanFloat(num) {
  return Math.abs(num) < 1e-10 ? 0 : Math.round(num * 1e12) / 1e12;
}

function safeTrig(fn, value) {
  const rad = toRadians(value);
  if (fn === 'tan' && Math.abs(Math.cos(rad)) < 1e-10) return 'Error';
  const result = fn === 'sin' ? Math.sin(rad) : fn === 'cos' ? Math.cos(rad) : Math.tan(rad);
  return cleanFloat(result);
}

function calculate(a, op, b) {
  a = parseFloat(a);
  b = parseFloat(b);
  switch (op) {
    case '+': return a + b;
    case '-': return a - b;
    case '*': return a * b;
    case '/': return b === 0 ? 'Error' : a / b;
    case '^': {
      const result = Math.pow(a, b);
      return isFinite(result) ? result : 'Error';
    }
    default: return b;
  }
}

// ============ DISPLAY ============
function updateDisplay() {
  currentOperandEl.textContent = currentInput;
  prevOperandEl.textContent = previousInput && operator ? `${previousInput} ${operator}` : '';
  angleModeEl.textContent = angleMode;
}

function setError() {
  currentInput = 'Error';
  previousInput = '';
  operator = null;
  resultJustShown = true;
  updateDisplay();
}

// ============ INPUT HANDLERS ============
function inputNumber(num) {
  if (currentInput === 'Error' || resultJustShown) {
    currentInput = '';
    resultJustShown = false;
  }
  if (num === '.' && currentInput.includes('.')) return;
  if (currentInput === '0' && num !== '.') {
    currentInput = num;
  } else {
    currentInput = currentInput === '' ? num : currentInput + num;
  }
  playSound('number');
  updateDisplay();
}

function chooseOperator(op) {
  if (currentInput === 'Error') return;
  if (previousInput !== '' && operator && !resultJustShown) {
    previousInput = calculate(previousInput, operator, currentInput).toString();
  } else {
    previousInput = currentInput;
  }
  operator = op;
  currentInput = '0';
  resultJustShown = false;
  playSound('operator');
  updateDisplay();
}

function equals() {
  if (operator === null || currentInput === 'Error') return;
  const result = calculate(previousInput, operator, currentInput);
  const expression = `${previousInput} ${operator} ${currentInput}`;

  if (result === 'Error') {
    setError();
    playSound('error');
    return;
  }

  addToHistory(expression, result.toString());
  currentInput = result.toString();
  previousInput = '';
  operator = null;
  resultJustShown = true;
  playSound('result');
  updateDisplay();
}

function clearAll() {
  currentInput = '0';
  previousInput = '';
  operator = null;
  resultJustShown = false;
  updateDisplay();
}

// ============ SCIENTIFIC FUNCTIONS ============
function applyUnary(action) {
  if (currentInput === 'Error') return;
  const value = parseFloat(currentInput);
  let result;
  let expression;

  switch (action) {
    case 'sqrt':
      result = value < 0 ? 'Error' : Math.sqrt(value);
      expression = `sqrt(${value})`;
      break;
    case 'square':
      result = value * value;
      expression = `${value}²`;
      break;
    case 'log':
      result = value <= 0 ? 'Error' : Math.log10(value);
      expression = `log(${value})`;
      break;
    case 'sin':
      result = safeTrig('sin', value);
      expression = `sin(${value}°/rad)`;
      break;
    case 'cos':
      result = safeTrig('cos', value);
      expression = `cos(${value}°/rad)`;
      break;
    case 'tan':
      result = safeTrig('tan', value);
      expression = `tan(${value}°/rad)`;
      break;
    default:
      return;
  }

  if (result === 'Error') {
    setError();
    playSound('error');
    return;
  }

  addToHistory(expression, result.toString());
  currentInput = result.toString();
  resultJustShown = true;
  playSound('result');
  updateDisplay();
}

function insertPi() {
  currentInput = Math.PI.toString();
  resultJustShown = true;
  updateDisplay();
}

function toggleAngleMode() {
  angleMode = angleMode === 'DEG' ? 'RAD' : 'DEG';
  updateDisplay();
}

// ============ HISTORY (localStorage) ============
function loadHistory() {
  const raw = localStorage.getItem('calc-history');
  return raw ? JSON.parse(raw) : [];
}

function saveHistory(history) {
  localStorage.setItem('calc-history', JSON.stringify(history));
}

function addToHistory(expression, result) {
  const history = loadHistory();
  history.unshift({ expression, result });
  if (history.length > 50) history.pop();
  saveHistory(history);
  renderHistory();
}

function renderHistory() {
  const history = loadHistory();
  historyList.innerHTML = '';
  history.forEach((item) => {
    const div = document.createElement('div');
    div.className = 'history-item';
    div.innerHTML = `<div class="expr">${item.expression}</div><div class="result">= ${item.result}</div>`;
    div.addEventListener('click', () => {
      currentInput = item.result;
      resultJustShown = true;
      updateDisplay();
    });
    historyList.appendChild(div);
  });
}

document.getElementById('clearHistory').addEventListener('click', () => {
  saveHistory([]);
  renderHistory();
});

document.getElementById('historyToggle').addEventListener('click', () => {
  historyPanel.classList.toggle('open');
});

document.getElementById('closeHistory').addEventListener('click', () => {
  historyPanel.classList.remove('open');
});

// ============ CLIPBOARD ============
async function copyResult() {
  await window.electronAPI.copyToClipboard(currentInput);
  flashCopyFeedback();
}

function flashCopyFeedback() {
  const original = currentOperandEl.style.color;
  currentOperandEl.style.color = '#4caf7d';
  setTimeout(() => {
    currentOperandEl.style.color = original;
  }, 200);
}

function sanitizeNumeric(text) {
  const cleaned = text.replace(/,/g, '').trim();
  return /^-?\d*\.?\d+$/.test(cleaned) ? cleaned : null;
}

async function pasteValue() {
  const text = await window.electronAPI.readFromClipboard();
  const sanitized = sanitizeNumeric(text);
  if (sanitized === null) return;
  currentInput = sanitized;
  resultJustShown = false;
  updateDisplay();
}

// ============ THEME ============
function loadTheme() {
  const saved = localStorage.getItem('calc-theme') || 'dark';
  document.body.classList.toggle('light', saved === 'light');
  document.getElementById('themeToggle').textContent = saved === 'light' ? '☀️' : '🌙';
}

function toggleTheme() {
  const isLight = document.body.classList.toggle('light');
  localStorage.setItem('calc-theme', isLight ? 'light' : 'dark');
  document.getElementById('themeToggle').textContent = isLight ? '☀️' : '🌙';
}

document.getElementById('themeToggle').addEventListener('click', toggleTheme);

// ============ WEB AUDIO ============
let audioCtx = null;

function getAudioContext() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  return audioCtx;
}

function playSound(kind) {
  if (isMuted) return;
  const ctx = getAudioContext();
  const oscillator = ctx.createOscillator();
  const gain = ctx.createGain();

  const frequencies = { number: 440, operator: 550, result: 660, error: 220 };
  oscillator.frequency.value = frequencies[kind] || 440;
  oscillator.type = 'sine';

  gain.gain.setValueAtTime(0.08, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.12);

  oscillator.connect(gain);
  gain.connect(ctx.destination);

  oscillator.start();
  oscillator.stop(ctx.currentTime + 0.12);
}

function loadMuteState() {
  isMuted = localStorage.getItem('calc-muted') === 'true';
  document.getElementById('muteToggle').textContent = isMuted ? '🔇' : '🔊';
}

function toggleMute() {
  isMuted = !isMuted;
  localStorage.setItem('calc-muted', isMuted.toString());
  document.getElementById('muteToggle').textContent = isMuted ? '🔇' : '🔊';
}

document.getElementById('muteToggle').addEventListener('click', toggleMute);

// ============ BUTTON WIRING ============
document.querySelectorAll('.btn[data-number]').forEach((btn) => {
  btn.addEventListener('click', () => inputNumber(btn.dataset.number));
});

const actionMap = {
  clear: clearAll,
  'deg-rad': toggleAngleMode,
  sqrt: () => applyUnary('sqrt'),
  square: () => applyUnary('square'),
  log: () => applyUnary('log'),
  sin: () => applyUnary('sin'),
  cos: () => applyUnary('cos'),
  tan: () => applyUnary('tan'),
  pi: insertPi,
  copy: copyResult,
  equals: equals,
  add: () => chooseOperator('+'),
  subtract: () => chooseOperator('-'),
  multiply: () => chooseOperator('*'),
  divide: () => chooseOperator('/'),
  power: () => chooseOperator('^')
};

document.querySelectorAll('.btn[data-action]').forEach((btn) => {
  btn.addEventListener('click', () => {
    const action = actionMap[btn.dataset.action];
    if (action) action();
  });
});

// ============ KEYBOARD SUPPORT ============
const keyToButtonSelector = {
  '+': '[data-action="add"]',
  '-': '[data-action="subtract"]',
  '*': '[data-action="multiply"]',
  '/': '[data-action="divide"]',
  '^': '[data-action="power"]',
  Enter: '[data-action="equals"]',
  '=': '[data-action="equals"]',
  Escape: '[data-action="clear"]',
  s: '[data-action="sin"]',
  c: '[data-action="cos"]',
  t: '[data-action="tan"]',
  r: '[data-action="sqrt"]',
  q: '[data-action="square"]',
  p: '[data-action="pi"]',
  l: '[data-action="log"]',
  d: '[data-action="deg-rad"]',
  h: '[data-action="history"]'
};

function pressVisual(selector) {
  const el = document.querySelector(selector);
  if (el) el.classList.add('pressed');
}

function releaseVisual(selector) {
  const el = document.querySelector(selector);
  if (el) el.classList.remove('pressed');
}

document.addEventListener('keydown', (e) => {
  if (/^[0-9]$/.test(e.key) || e.key === '.') {
    inputNumber(e.key);
    return;
  }

  if (e.key === 'h') {
    historyPanel.classList.toggle('open');
    return;
  }

  const selector = keyToButtonSelector[e.key];
  if (selector) {
    pressVisual(selector);
    const el = document.querySelector(selector);
    if (el) el.click();
  }

  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c') {
    copyResult();
  }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v') {
    pasteValue();
  }
});

document.addEventListener('keyup', (e) => {
  const selector = keyToButtonSelector[e.key];
  if (selector) releaseVisual(selector);
});

// ============ INIT ============
loadTheme();
loadMuteState();
renderHistory();
updateDisplay();
